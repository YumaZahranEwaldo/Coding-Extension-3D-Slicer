import os
import unittest
import logging
import slicer.util
import slicer, vtk, qt, ctk
from slicer.ScriptedLoadableModule import *
from slicer.util import VTKObservationMixin
from skimage.morphology import disk
from skimage.segmentation import morphological_geodesic_active_contour, inverse_gaussian_gradient
import numpy as np

class NerveModule(ScriptedLoadableModule):
    def __init__(self, parent):
        ScriptedLoadableModule.__init__(self, parent)
        self.parent.title = "Nerve Module"
        self.parent.categories = ["Examples"]
        self.parent.dependencies = []
        self.parent.contributors = ["Yuma"]
        self.parent.helpText = "Modul ini sebagai segmentator Center Nervous System berbasis semi otomatis dan full otomatis"
        self.parent.acknowledgementText = "-"
        
class NerveModuleWidget (ScriptedLoadableModuleWidget, VTKObservationMixin):
    def __init__(self, parent=None):
        ScriptedLoadableModuleWidget.__init__(self,parent)
        VTKObservationMixin.__init__(self)
     
    def setup(self):
        ScriptedLoadableModuleWidget.setup(self)
        
        uiWidget = slicer.util.loadUI(self.resourcePath('UI/NerveModule.ui'))
        self.layout.addWidget(uiWidget)
        self.ui = slicer.util.childWidgetVariables(uiWidget)
        
        #Input
        self.ui.MRMLNodeComboBox.nodeTypes = ["vtkMRMLScalarVolumeNode"]
        self.ui.MRMLNodeComboBox.selectNodeUponCreation = True
        self.ui.MRMLNodeComboBox.addEnabled = False
        self.ui.MRMLNodeComboBox.removeEnabled = False
        self.ui.MRMLNodeComboBox.noneEnabled = False
        self.ui.MRMLNodeComboBox.showHidden = False
        self.ui.MRMLNodeComboBox.showChildNodeTypes = False
        self.ui.MRMLNodeComboBox.setMRMLScene(slicer.mrmlScene)
        self.ui.MRMLNodeComboBox.setToolTip("Pick the input volume.")
        
        #Output
        self.ui.MRMLNodeComboBox_2.nodeTypes = ["vtkMRMLSegmentationNode"]
        self.ui.MRMLNodeComboBox_2.selectNodeUponCreation = True
        self.ui.MRMLNodeComboBox_2.addEnabled = True
        self.ui.MRMLNodeComboBox_2.removeEnabled = True
        self.ui.MRMLNodeComboBox_2.noneEnabled = True
        self.ui.MRMLNodeComboBox_2.showHidden = False
        self.ui.MRMLNodeComboBox_2.showChildNodeTypes = False
        self.ui.MRMLNodeComboBox_2.setMRMLScene(slicer.mrmlScene)
        self.ui.MRMLNodeComboBox_2.setToolTip("Pick the Output Segmentation.")
        
        #Treshold
        self.ui.MRMLSliderWidget.singleStep = 1.0
        self.ui.MRMLSliderWidget.minimum = 0
        self.ui.MRMLSliderWidget.maximum = 100
        self.ui.MRMLSliderWidget.value = 1.0
        
        #Button
        self.ui.pushButton_3.connect('clicked(bool)', self.onScanButton)
        self.ui.pushButton_2.connect('clicked(bool)', self.onApplyButton)
        self.ui.toolButton.connect('clicked(bool)', self.onToolButton)
        
        self.initializeParameterNode()
        
    def getKernelSizePixel(self):
        return 3 
        
    def createColoredLabelmap(self, inputVolume, threshold):
        imageData = inputVolume.GetImageData()
        dimensions = imageData.GetDimensions()
        
        labelmap = vtk.vtkImageData()
        labelmap.CopyStructure(inputVolume.GetImageData())
        labelmap.AllocateScalars(vtk.VTK_UNSIGNED_CHAR, 3)
        
        for z in range(dimensions[2]):
            for y in range(dimensions[1]):
                for x in range(dimensions[0]):
                    value = imageData.GetScalarComponentAsFloat(x, y, z, 0)
                    if value > threshold:
                        labelmap.SetScalarComponentFromFloat(x, y, z, 0, 255)
                        labelmap.SetScalarComponentFromFloat(x, y, z, 1, 0)
                        labelmap.SetScalarComponentFromFloat(x, y, z, 2, 0)
                    else:
                        labelmap.SetScalarComponentFromFloat(x, y, z, 0, 0)
                        labelmap.SetScalarComponentFromFloat(x, y, z, 1, 0)
                        labelmap.SetScalarComponentFromFloat(x, y, z, 2, 0)
                        
        return labelmap
    
    #def onThresholdChanged(self, newValue):
       # inputVolume = self.ui.MRMLNodeComboBox.currentNode()
        #if not inputVolume:
            #return
        
        #labelmap = self.createColoredLabelmap(inputVolume, newValue)
        
        #if not hasattr(self, 'coloredLabelmapNode'):
            #self.coloredLabelmapNode = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLScalarVolumeNode", "ColoredLabelmap")
            #displayNode = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLScalarVolumeDisplayNode")
            #self.coloredLabelmapNode.SetAndObserveDisplayNodeID(displayNode.GetID())
            #displayNode.SetAndObserveColorNodeID("vtkMRMLColorTableNodeRainbow")
            
        #self.coloredLabelmapNode.SetAndObserveImageData(labelmap)
        #slicer.util.setSliceViewerLayers(background=inputVolume, foreground=self.coloredLabelmapNode, foregroundOpacity=0.5)   
   
    def initializeParameterNode(self):
        """
        Ensure parameter node exists and observed.
        """
        
        self.logic = NerveModuleLogic() 

    def onToolButton(self):
        
        if not hasattr(self, 'fiducialNode') or self.fiducialNode is None:
            self.fiducialNode = slicer.mrmlScene.GetFirstNodeByName("SegmentaionSeed")
            if not self.fiducialNode:
                self.fiducialNode = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLMarkupsFiducialNode", "SegmentationSeed")
            
        interactionNode = slicer.app.applicationLogic().GetInteractionNode()
        interactionNode.SetCurrentInteractionMode(slicer.vtkMRMLInteractionNode.Place)
        self.fiducialNode.SetLocked(False)
        
        slicer.modules.markups.logic().StartPlaceMode(0)
        
    def applyActiveContour(self, inputVolume, seedPoint, iterations = 100):
        imageArray = slicer.util.arrayFromVolume(inputVolume)
    
        z, y, x = seedPoint
        if not (0 <= z < imageArray.shape[0] and 0 <= y < imageArray.shape[1] and 0 <= x < imageArray.shape[2]):
            print("❌ Seed point out of bounds:", seedPoint)
            return None

        print(f"✅ Seed intensity at {seedPoint}: {imageArray[z, y, x]}")
        
        init_ls = np.zeros_like(imageArray, dtype=bool)
        
        r = 10  
        z_min = max(0, z - r)
        z_max = min(imageArray.shape[0], z + r)
        y_min = max(0, y - r)
        y_max = min(imageArray.shape[1], y + r)
        x_min = max(0, x - r)
        x_max = min(imageArray.shape[2], x + r)
        init_ls[z_min:z_max, y_min:y_max, x_min:x_max] = 1
        
        gimage = inverse_gaussian_gradient(imageArray)
        print("📊 Gradient stats — min:", np.min(gimage), "max:", np.max(gimage))

        ls = morphological_geodesic_active_contour(gimage, num_iter = iterations, init_level_set = init_ls, smoothing = 3)
        
        print("🔍 Resulting ls array — Max of ls:", np.max(ls), "Min of ls:", np.min(ls))
        
        if np.max(ls) == 0:
            print("⚠️ Active contour result is empty (no segmented area).")
            return None
        
        return (ls > 0).astype(np.uint8) * 255

    def onScanButton(self):
        pass
        

    def onApplyButton(self):
        
        from qt import  QProgressDialog, Qt
        from skimage.segmentation import morphological_geodesic_active_contour, inverse_gaussian_gradient
        import numpy as np

        inputVolume = self.ui.MRMLNodeComboBox.currentNode()
        outputSegmentation = self.ui.MRMLNodeComboBox_2.currentNode() 
        
        if not inputVolume or not outputSegmentation:
            slicer.util.errorDisplay("Silahkan masukkan input dan output terlebih dahulu")
            return
        
        fiducialNode = slicer.mrmlScene.GetFirstNodeByName("SegmentationSeed")
        if not fiducialNode or fiducialNode.GetNumberOfControlPoints() == 0:
            slicer.util.errorDisplay("silahkan pilih bagian yang akan disegmentasi")
            return
        
        ras = [0, 0, 0]
        fiducialNode.GetNthControlPointPosition(0, ras)
        
        ijk = [0, 0, 0]
        volumeRASToIJK = vtk.vtkMatrix4x4()
        inputVolume.GetRASToIJKMatrix(volumeRASToIJK)
        ras_hom = ras + [1]
        ijk_float = [0, 0, 0, 0]
        volumeRASToIJK.MultiplyPoint(ras_hom, ijk_float)
        ijk = list(map(int, ijk_float[:3]))
        print(f"Seed Voxel (IJK): {ijk}")
        
        imageArray = slicer.util.arrayFromVolume(inputVolume)
        z, y, x = ijk[2], ijk[1], ijk[0]

        if not (0 <= z < imageArray.shape[0] and 0 <= y < imageArray.shape[1] and 0 <= x < imageArray.shape[2]):
            slicer.util.errorDisplay(f"❌ Seed point {ijk} out of image array bounds {imageArray.shape}")
            return

        init_ls = np.zeros_like(imageArray, dtype=bool)
        r = 30
        init_ls[max(0, z-r):min(z+r, imageArray.shape[0]),
                max(0, y-r):min(y+r, imageArray.shape[1]),
                max(0, x-r):min(x+r, imageArray.shape[2])] = 1

        gimage = inverse_gaussian_gradient(imageArray)
        ls = morphological_geodesic_active_contour(
            gimage,
            num_iter=120,
            init_level_set=init_ls,
            smoothing=3,
            balloon=1
        )


        if np.max(ls) == 0:
            slicer.util.errorDisplay("Segmentasi gagal. Hasil dari active contour kosong atau seed point salah.")
            return

        binaryMask = (ls > 0).astype(np.uint8)
        
        labelmapNode = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLLabelMapVolumeNode", "TempLabelmap")
        slicer.util.updateVolumeFromArray(labelmapNode, binaryMask)
        labelmapNode.SetSpacing(inputVolume.GetSpacing())
        labelmapNode.SetOrigin(inputVolume.GetOrigin())

        matrix = vtk.vtkMatrix4x4()
        inputVolume.GetIJKToRASMatrix(matrix)
        labelmapNode.SetIJKToRASMatrix(matrix)
        
        outputSegmentation.CreateDefaultDisplayNodes()
        outputSegmentation.SetReferenceImageGeometryParameterFromVolumeNode(inputVolume)
        slicer.modules.segmentations.logic().ImportLabelmapToSegmentationNode(labelmapNode, outputSegmentation)

        segmentation = outputSegmentation.GetSegmentation()
        if segmentation.GetNumberOfSegments() == 0:
            segmentId = segmentation.AddEmptySegment("ActiveContourSegment")
        else:
            segmentId = segmentation.GetNthSegmentID(0)
            segmentation.GetSegment(segmentId).SetName("ActiveContourSegment")
        
        if not segmentation.CreateRepresentation("ClosedSurface"):
            slicer.util.errorDisplay("❌ Gagal membuat ClosedSurface representation untuk segmentasi!")
            return

        displayNode = outputSegmentation.GetDisplayNode()
        if displayNode:
            displayNode.SetVisibility(True)
            displayNode.SetVisibility3D(True)
            displayNode.SetVisibility2DFill(True)
            displayNode.SetVisibility2DOutline(True)

        slicer.util.setSliceViewerLayers(background=inputVolume, label=outputSegmentation, labelOpacity=0.5)
        slicer.app.applicationLogic().GetSelectionNode().SetReferenceActiveVolumeID(inputVolume.GetID())
        slicer.app.applicationLogic().PropagateVolumeSelection()

        slicer.mrmlScene.RemoveNode(labelmapNode)
        slicer.mrmlScene.RemoveNode(fiducialNode)
        
class NerveModuleLogic(ScriptedLoadableModuleLogic):
    def __init__(self):
        ScriptedLoadableModuleLogic.__init__(self)
        
    def process(self, inputVolume, outputSegmentation, threshold):
        """
        Run the processing algoritm.
        can be used without GUI widget
        """
        if not inputVolume or not outputSegmentation:
            raise ValueError("Input or output volume in invalid")
        
        import time
        startTime = time.time()
        logging.info('Processing started')
        
        stopTime = time.time
        logging.info(f'Processing completed in {stopTime-startTime:.2f} seconds')
        
        return True

class NerveModuleTest(ScriptedLoadableModuleTest):
    def setUp(self):
        """
        Do whatever is needed to reset the state - typically a scene clear will be enough.
        """
        slicer.mrmlScene.Clear()
        
    def runTest(self):
        """
        Run as few or as many tests as needed here.
        """
        self.setUp()
        self.test_NerveModule1()
        
    def test_NerveModule1(self):
        """
        Ideally you should have several levels of tests.
        """
        self.delayDisplay("Starting the test")
        self.delayDisplay('Test Passed')
        